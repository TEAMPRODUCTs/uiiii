﻿define(['libs', 'c', 'cBasePageView'],
    function (libs, c, basePageView) {
    var View = basePageView.extend({
        
    });
    return View;
});